package hw2;

import java.util.Random;

public class Task3 {
    public static void main(String[] args) {
        final Random random = new Random();
        int number1 = random.nextInt(1000);
        System.out.println(number1);

        if (number1 % 2 != 0) {
            System.out.println("Число не чётное");
        } else {
            System.out.println("Число чётное");
        }
        System.out.println(number1 % 2 != 0? "число не чётное" : "число  чётное");
    }
}
