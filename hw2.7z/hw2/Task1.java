package hw2;

import java.util.Random;

public class Task1 {

    public static void main(String args[]) {
        final Random random = new Random();
        double x1 = random.nextInt (1000);
        double x2 = random.nextInt (1000);
        double x3 = random.nextInt (1000);

        System.out.println(Math.sqrt(60));

        double p = (x1 + x2 + x3) / 2;
        double s = Math.sqrt(p * (p - x1) * (p - x2) * (p - x3));
        System.out.println("Площадь треугольника равна " + s);
    }

}


