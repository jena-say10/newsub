package hw2;

import java.util.Random;

public class Task2 {
    public static void main(String args[]) {
        final Random random = new Random();
        int number1 = random.nextInt(1000);
        int number2 = random.nextInt(1000);
        int number3  = random.nextInt(1000);
        System.out.println(number1);
        System.out.println(number2);
        System.out.println(number3);


        number1 = Math.abs(number1);
        number2 = Math.abs(number2);
        number3 = Math.abs(number3);
        int min = number1;
        min = min>number2?number2:min;
        min = min>number3?number3:min;
        System.out.println("min = " + min);

    }

}
